-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA256


Installing commandoo (upgrading is explained further down)
- - ---------------------


Pleez read this whole file before running.


My gnuGPG key is 0x74E59DD3 2013-12-09
as JuliuS Inet (internet signing).


There are, as of March 2018, two versions available for Debian and debian derivatives (32 bit has been discontinued):

64 bit QT
64 bit GTK

available at:
  https://github.com/Juuliuus/commandoo/
alternative:
  https://www.timepirate.org/downloads.html

commandoo has been developed and tested in 64 bit Debian 8 (Jessie) and tested in 64 bit Kubuntu 14.04 KDE. 


It should, therefore, work in all debian 8 & 9 linux derivatives.


commandoo is a self-sufficient (99.9%) file. Unarchive commandoo from the tar.gz file and place it in this folder, you may need to mark commandoo as executable first (but read all of this file first pleez). 

You don't have to use this folder, you can place commandoo in any folder you like, but then you won't have the starter database, search examples, translations, and cool screenshots. 

On a first run there will be a series of messages regarding setup. 

See github link above for latest notes.


==============================

     IMPORTANT! ===> Information regarding QT versions. <== IMPORTANT!

You: "Aaaaagh! It doesn't run!!"
=========================
The 0.01% part:
The QT versions of commandoo use the QT widget set. If commandoo doesn't run don't get mad at me! It is simply a matter of needing to install a library called: 

libqt4pas5   

This library is found in standard linux repositories. Use your package manager or apt-get. It is a library that serves as the go-between for lazaraus pascal computer language ('pas') and QT Libraries. 

==> And of course also make sure commandoo is marked as executable (it is shipped as executable but I've found on occasion that copying it to a new system changes this).

==============================


If you do choose to use this folder with db's and searches you get a 'starter' database (both a text based and a sql based; text base is default).

The starter database has more than 170 Linux commands and examples. You can add your own favorite commands and command lines at will! (Or even start new databases as you like)


If you want try the other executable (Qt if you used GTK, or GTK if you used Qt, or, if in future, you download a commandoo update) all you need to do is replace the commandoo file ( !!AND install libqt4pas5 if you use the QT version!! And mark it as executable ). 


If you use this folder, you also have a choice of 3 languages:

English
Pyrate
Wookie

Pyrate and Wookie were developed for testing language translation code and I give them to you for fun. You won't like Wookie, probably, but if you are feeling brave...

Other translations are needed, if you feel up to it contact me through github. 

In future if any new translations become available they will be at the github site under the 'languages' folder which is in the 'code' folder (the 'po_files' folder is a list of language files that are not yet translated). Translated language files will also be at the TimePirate site.


commandoo was designed in QT widget set. So QT versions will be prettier than the GTK versions.

And I won't lie: There may be some irregularities and display issues in GTK versions but it does work and is usable. If the oddities are really bad try the other widget set (QT if you tried GTK, or GTK if you tried QT). Using the proper one makes a difference.


Upgrading:
==========
The current version of commandoo is 1.0.1. If you are one of the brave that installed 1.0.0/1.1.0 you only need to overwrite the "commandoo" file with the version want, QT or GTK. BUT. If you are also using translations the old translations won't be complete. Simply download the po_translations_1.0.1.tar.gz file and unarchive right into the languages folder. Make sure commandoo is marked as executable. Upgrade is finished.

if anyone installed the earlier 32 bit versions: 32 bit versions are no longer automatically compiled and posted by me. If you have the 1.0.0 32 bit version and want to move up to 1.0.1 contact me and I'll compile you one.


This program was built using free pascal and the Lazarus IDE. Thank you FPC and Lazarus.


Enjoy.

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCAAdFiEESx3/ftprDob4Xk7NHbV3r3TlndMFAlqs9TQACgkQHbV3r3Tl
ndPQIA/+NstavChEfuuXYsNbYiE9HZQDZO+ghCQE3qXfgS683/DrDmx4mw4VkXQP
M7LfPwaY/sjdeH2YPBjeoFHzyR0N+HY3MjKjgRgRhXGoeiijKl8rwcB1eLQ+Raab
3xcRGhXUgwoX0+MBn0+3nUoksxMIO+ygG0ZWKXgEsR/0RXEGX2oFswosL+pAOCpJ
LnIeKwdVUummf7kdesju9c1reBsTtkBT3L3uDv92EUTGKH+X3KkG51lWM8+wFPWv
aQYm+ByrVu3ba6ZhVz90B3pkhPIC//8ip10X4YIOiLGBQydEqkhbOuBFdV0Fh114
wmB46xKxKo6ZLwX3C1J+orfx5oD19TuNZahEcciBw3OD7JReB1Bhr2yZc3hUnKda
er59kEYYJAV2TwOhgUH9Nai+F6Rnmu3kGsJJrffmQrPXzONYyId5hQfFvBRYTRiD
0EdlclSo07pqJStSxpcFEkUpPS9V4ELzfJqjEHAvIP5C6TedR/qIIdMHkYw+xTA5
P6JwckXmVcVB4P3kpALSltiFkQYc1H4zaguEBSMAH2HD98veiradLLdRE8SqlXBl
r6DLVkiOiQFOh0iNJqC3VWPjgGQpZy1eSne0FWpCxk/jvQqNd6jSWm4WPcchQjfU
SRMlpR0k7DWrMFJ+qusVd4fY+IqmwH/TkQO82zgHQcfFwJphUbA=
=Ze/C
-----END PGP SIGNATURE-----
